google.maps.__gjsload__('search_impl', function(_) {
    var spb = function(a, b) {
            _.H(a.Hg, 3, b)
        },
        wpb = function(a, b, c) {
            const d = _.vK(new tpb);
            c.Uq = (0, _.Da)(d.load, d);
            c.clickable = a.get("clickable") != 0;
            _.$Ra(c, _.uR(b));
            const e = [];
            e.push(_.wk(c, "click", (0, _.Da)(upb, null, a)));
            _.Ob(["mouseover", "mouseout", "mousemove"], function(f) {
                e.push(_.wk(c, f, (0, _.Da)(vpb, null, a, f)))
            });
            e.push(_.wk(a, "clickable_changed", function() {
                a.Eg.clickable = a.get("clickable") != 0
            }));
            a.Fg = e
        },
        upb = function(a, b, c, d, e) {
            let f = null;
            if (e && (f = {
                    status: e.getStatus()
                }, e.getStatus() == 0)) {
                f.location = _.U(e.Hg,
                    2) ? new _.Qj(_.Hu(_.K(e.Hg, 2, _.Mu).Hg, 1), _.Hu(_.K(e.Hg, 2, _.Mu).Hg, 2)) : null;
                f.fields = {};
                const g = _.Di(e.Hg, 3);
                for (let h = 0; h < g; ++h) {
                    const k = _.Is(e.Hg, 3, _.FR, h);
                    f.fields[k.getKey()] = k.getValue()
                }
            }
            _.Kk(a, "click", b, c, d, f)
        },
        vpb = function(a, b, c, d, e, f, g) {
            let h = null;
            f && (h = {
                title: f[1].title,
                snippet: f[1].snippet
            });
            _.Kk(a, b, c, d, e, h, g)
        },
        xpb = function() {},
        ypb = class extends _.R {
            constructor() {
                super()
            }
            Wi() {
                return _.Vi(this.Hg, 2)
            }
        },
        zpb = [_.L, , , _.Iq, _.gTa];
    var Apb = class extends _.R {
        constructor(a) {
            super(a)
        }
        getStatus() {
            return _.I(this.Hg, 1, -1)
        }
        getLocation() {
            return _.Ni(this.Hg, 2, _.Mu)
        }
    };
    var tpb = class {
        constructor() {
            var a = _.zp,
                b = _.wp;
            this.Fg = _.Xi;
            this.Eg = _.Ds(_.yy, a, _.Tz + "/maps/api/js/LayersService.GetFeature", b)
        }
        load(a, b) {
            function c(g) {
                g = new Apb(g);
                b(g)
            }
            var d = new ypb;
            _.H(d.Hg, 1, a.layerId.split("|")[0]);
            _.H(d.Hg, 2, a.featureId);
            spb(d, this.Fg.Eg().Eg());
            for (var e in a.parameters) {
                var f = _.Qi(d.Hg, 4, _.FR);
                _.H(f.Hg, 1, e);
                _.H(f.Hg, 2, a.parameters[e])
            }
            a = _.Ki(d.xi(), zpb, 1);
            this.Eg(a, c, c);
            return a
        }
        cancel() {
            throw Error("Not implemented");
        }
    };
    xpb.prototype.IE = function(a) {
        if (_.Nn[15]) {
            var b = a.Ig;
            const c = a.Ig = a.getMap();
            b && a.Eg && (a.Gg ? (b = b.__gm.Xj, b.set(b.get().Bn(a.Eg))) : a.Eg && _.wSa(a.Eg, b) && (_.Ob(a.Fg || [], _.yk), a.Fg = null));
            if (c) {
                b = new _.Hx;
                const d = a.get("layerId").split("|");
                b.layerId = d[0];
                for (let e = 1; e < d.length; ++e) {
                    const [f, ...g] = d[e].split(":");
                    b.parameters[f] = g.join(":")
                }
                a.get("spotlightDescription") && (b.spotlightDescription = new _.$x(a.get("spotlightDescription")));
                a.get("paintExperimentIds") && (b.paintExperimentIds = a.get("paintExperimentIds").slice(0));
                a.get("styler") && (b.styler = new _.Sx(a.get("styler")));
                a.get("roadmapStyler") && (b.roadmapStyler = new _.Sx(a.get("roadmapStyler")));
                a.get("travelMapRequest") && (b.travelMapRequest = new _.rla(a.get("travelMapRequest")));
                a.get("mapsApiLayer") && (b.mapsApiLayer = new _.Nx(a.get("mapsApiLayer")));
                a.get("mapFeatures") && (b.mapFeatures = a.get("mapFeatures"));
                a.get("clickableCities") && (b.clickableCities = a.get("clickableCities"));
                a.get("searchPipeMetadata") && (b.searchPipeMetadata = new _.Cz(a.get("searchPipeMetadata")));
                a.get("gmmContextPipeMetadata") && (b.gmmContextPipeMetadata = new _.Fja(a.get("gmmContextPipeMetadata")));
                a.get("overlayLayer") && (b.overlayLayer = new _.ay(a.get("overlayLayer")));
                a.get("caseExperimentIds") && (b.caseExperimentIds = a.get("caseExperimentIds").slice(0));
                a.get("boostMapExperimentIds") && (b.boostMapExperimentIds = a.get("boostMapExperimentIds").slice(0));
                a.get("airQualityPipeMetadata") && (b.airQualityPipeMetadata = new _.Wka(a.get("airQualityPipeMetadata")));
                a.get("directionsPipeParameters") && (b.directionsPipeParameters =
                    new _.qA(a.get("directionsPipeParameters")));
                a.get("clientSignalPipeMetadata") && (b.clientSignalPipeMetadata = new _.mja(a.get("clientSignalPipeMetadata")));
                b.darkLaunch = !!a.get("darkLaunch");
                a.Eg = b;
                a.Gg = a.get("renderOnBaseMap");
                a.Gg ? (a = c.__gm.Xj, a.set(a.get().Fl(b))) : wpb(a, c, b);
                _.Il(c, "Lg");
                _.Gl(c, 148282)
            }
        }
    };
    _.lk("search_impl", new xpb);
});